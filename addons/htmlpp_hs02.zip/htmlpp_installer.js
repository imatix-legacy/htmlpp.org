/*	htmlpp_installer.js   Generates the ToolBar for the 'HomeSite ActiveScrips for
		Htmlpp' v.0.2

	Author: Enrique Bengoechea <ebb@eco.uc3m.es>
	Written: March 13, 1999
	Last Modified: March 13, 1999
	Version: 0.2

    This script is free software; you can redistribute it and/or modify   
    it under the terms of the GNU General Public License as published by    
    the Free Software Foundation <http://www.gnu.org/copyleft/gpl.html>;
	either version 2 of the License, or (at your option) any later version.                                      
	
	Installation: See the accompanying 'readme.txt' file.
	If you find the scripts useful or have any suggestion, I would thank an e-mail.

	Copyright (c) 1999 Enrique Bengoechea
	For other scripts or updated versions: <http://www.eco.uc3m.es/~ebb/>
*/

// create constants for prompts (easier to remember) - Just a subset; the ones I'm using in this script
var hsOK = 0;
var hsYesNoCancel = 3;
var hsYesNo = 4;
var hsYesNoCancelQuestion = 35;
var hsYesNoQuestion = 36;
var hsOKAlert = 48;
var hsOKInfo = 64;

// MessageBox button values
var hsOKValue = 1;
var hsCancel = 2;
var hsAbort =3;
var hsRetry = 4;
var hsIgnore = 5;
var hsYes = 6;
var hsNo = 7;


function Main() {
	var app = Application;
	var active = app.ActiveDocument;
	// Customize this variable to your system!
	var HtmlppPath = 'C:\\htmlpp\\';
	var HtmlppScriptsPath = app.AppPath + 'scripts\\htmlpp\\';
	var BarName = "Htmlpp"

	if (app.ToolbarExists(BarName)) {
		answer = app.MessageBox("There already exists a ToolBar named '"+BarName+"', probably with a " +
		"previous version of the Scripts.\n" +
		"Do you want to substitute the existing ToolBar with the new one?","Delete Old ToolBar",
		hsYesNo);
		if (answer == hsYes) {
			app.DeleteToolbar(BarName);
		} else {
			return;
		}
	}

	app.CreateToolbar(BarName);			

	app.AddScriptToolbutton(BarName, HtmlppScriptsPath+"htmlpp.js",
		 "Htmlpp", "", HtmlppScriptsPath+"htmlpp.bmp");
		 
	app.AddScriptToolbutton(BarName, HtmlppScriptsPath+"htmlpp_opprocfiles.js",
		 "Open Generated Files", "", HtmlppScriptsPath+"open_HTML.bmp");

	app.AddScriptToolbutton(BarName, HtmlppScriptsPath+"htmlpp_brfile.js",
		 "Browse Generated File", "", HtmlppScriptsPath+"open-browse.bmp");
		 
	app.AddScriptToolbutton(BarName, HtmlppScriptsPath+"htmlpp_opwrk.js",
		 "Open Working Files", "", HtmlppScriptsPath+"open_wrk.bmp");
		 
	app.AddScriptToolbutton(BarName, HtmlppScriptsPath+"htmlpp_clall.js",
		 "Close Last-Run Files", "", HtmlppScriptsPath+"close_all.bmp");
		 
	app.AddScriptToolbutton(BarName, HtmlppScriptsPath+"htmlpp_opinclude.js",
		 "Open Included Files", "", HtmlppScriptsPath+"include.bmp");
 
	app.ShowToolbar(BarName);
}