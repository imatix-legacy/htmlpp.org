/*	htmlpp_opinclude.js: Opens all '.include'd files in active Htmlpp document.

	Author: Enrique Bengoechea <ebb@eco.uc3m.es>
	Written: March 9, 1999
	Last Modified:  March 12, 1999
	Version: 0.2
		
    This script is free software; you can redistribute it and/or modify   
    it under the terms of the GNU General Public License as published by    
    the Free Software Foundation <http://www.gnu.org/copyleft/gpl.html>;
	either version 2 of the License, or (at your option) any later version.                                      
	
	Installation: See the accompanying 'readme.txt' file.
	If you find the scripts useful or have any suggestion, I would thank an e-mail.

	Copyright (c) 1999 Enrique Bengoechea
	For other scripts or updated versions: <http://www.eco.uc3m.es/~ebb/>
*/

// create constants for prompts (easier to remember) - Just a subset; the ones I'm using in this script
var hsOK = 0;
var hsYesNoCancel = 3;
var hsYesNo = 4;
var hsYesNoCancelQuestion = 35;
var hsYesNoQuestion = 36;
var hsOKAlert = 48;
var hsOKInfo = 64;

var ForReading = 1;

// MessageBox button values
var hsOKValue = 1;
var hsCancel = 2;
var hsAbort =3;
var hsRetry = 4;
var hsIgnore = 5;
var hsYes = 6;
var hsNo = 7;

function Main() {
	var app = Application;
	var active = app.ActiveDocument;

	// Customize this variable to your system!
	var HtmlppScriptsPath = 'scripts\\htmlpp\\';
	var LastProcessFile = app.AppPath + HtmlppScriptsPath +  "last_proc.txt";
	
	app.CurrentView = 1; 	// Edit mode

	// Everything will work only if the active file has extensions 'htp' or 'def'.
	var objSearch = /\.htp$|\.def$/i;	
	fname = app.ExtractFileName(active.Filename);
	if (! objSearch.test(fname)) {
		var fso = new ActiveXObject("Scripting.FileSystemObject");
		if (fso.FileExists(LastProcessFile)) {
			// Parse 'last_process.txt' line by line
			var LastProcessFileObj = fso.OpenTextFile(LastProcessFile, ForReading);		
			var objSearch = /^SourceFile\s*=\s*(\S+)/;	
			
			while (!LastProcessFileObj.AtEndOfStream) {
				var LastProcessText = LastProcessFileObj.ReadLine();		
				if (objSearch.test(LastProcessText)) {
					if (RegExp.$1 != "NONE") {
						if (app.IsFileOpen(RegExp.$1)) { // If it's open just make it active
							app.DocumentIndex = app.GetTabIndexForFile(RegExp.$1);
						} else { // Or else open it
							app.MessageBox("Active file doesn't have extensions '.htp' or '.def' "+
							"and file '"+RegExp.$1 +"' is not open", "Htmlpp doc not found", hsOKAlert);	
							return;
						}
					}									
				}
			} 
	
			LastProcessFileObj.close();
		} else {
			app.MessageBox("Active file doesn't have extensions '.htp' or '.def' "+
			"and can't find file 'last_process.txt'","Htmlpp doc not found",hsOKAlert);
			return;
		}	
	}

	var Path = app.ExtractFilePath(active.Filename);		
	strText = active.Text;		
	if (strText.length > 0) {
		var index = 0;
		var newindex = 0;
		var objSearch = /\n\.\s*include\s+([\w\d_~\-\\\/\.]+)/g;
		var objSearchDir = /^\.\//;	
		var objSearchCur = /[\\\/]+/;
		var file = "";
		if (objSearch.test(strText)) {
			var fso = new ActiveXObject("Scripting.FileSystemObject");
			
			var resArray = strText.match(objSearch);
			for (i=0; resArray.length > i; i++) {
				newindex = strText.indexOf(resArray[i], index);
				var string = resArray[i];
				file = string.match(objSearch);
				file = RegExp.$1;
				// If a filename starts by './', change the path to be absolute
				if (objSearchDir.test(file)) { 
					file = Path + file.slice(2);
				}
				else {
					if (! objSearchDir.test(file)) {
						file = Path + file;
					}				
				}
				if (app.IsFileOpen(file)) { // If it's open just make it active
					app.DocumentIndex = app.GetTabIndexForFile(file);
				} else { // Or else open it
					if (fso.FileExists(file)) {
						app.OpenFile(file);
					} else {
						app.MessageBox("File '"+file+"' not found", "Unexisting File", hsOKAlert);					
					}
				}				
				index = newindex + resArray[i].length;
			}
		} else { 
			app.MessageBox("No Included Files Found", "No Included Files", hsOKAlert);
		}
	}
	   
}
