/*	htmlpp.js   Process a document with Htmlpp 

	Author: Enrique Bengoechea <ebb@eco.uc3m.es>
	Written: March 9, 1999
	Last Modified: March 12, 1999
	Version: 0.2

    This script is free software; you can redistribute it and/or modify   
    it under the terms of the GNU General Public License as published by    
    the Free Software Foundation <http://www.gnu.org/copyleft/gpl.html>;
	either version 2 of the License, or (at your option) any later version.                                      
	
	Installation: See the accompanying 'readme.txt' file.
	If you find the scripts useful or have any suggestion, I would thank an e-mail.

	Copyright (c) 1999 Enrique Bengoechea
	For other scripts or updated versions: <http://www.eco.uc3m.es/~ebb/>
*/

// Customize this variable to your system!
var HtmlppPath = 'C:\\htmlpp\\';
var HtmlppScriptsPath = 'scripts\\htmlpp\\';

// create constants for prompts (easier to remember) - Just a subset; the ones I'm using in this script
var hsOK = 0;
var hsYesNoCancel = 3;
var hsYesNo = 4;
var hsYesNoCancelQuestion = 35;
var hsYesNoQuestion = 36;
var hsOKAlert = 48;
var hsOKInfo = 64;

var ForReading = 1;

// MessageBox button values
var hsOKValue = 1;
var hsCancel = 2;
var hsAbort =3;
var hsRetry = 4;
var hsIgnore = 5;
var hsYes = 6;
var hsNo = 7;

var app = Application;
var active = app.ActiveDocument;
// Get tab index for source document
var idx = app.GetTabIndexForFile(active.Filename);

function mySRDialog() {	// object to be passed to rich HTML dialog
	var OptDebug;
	var OptGuru;	
	var OptEnv;
	var OptNofunc;
	var OptExpired;
	var OptConnect;	
	var OptNoConnect;	
	var FileDoc = "";
	var SetSpanish;
	var SetEnglish;
	var Charset;
	var Pages = "";
	var Set = "";
	var EditOutput;
	var EditHTML;
	var BrowseHTML;
	var EditWrk;
}

function ReturnHTMLFiles(strText) {
	// Parses output file htmlpp.out for generated HTML files and returns an array with
	// all those file names.
//    var strText = app.ActiveDocument.Text;
	var GenFiles = new Array();		
	
	if (strText.length > 0) {
		var index = 0;
		var newindex = 0;
		var objSearch = /htmlpp I: creating ([\w:_\.\-\\\/]+)\.\.\./gi;
		var objSearchDir = /^\.\//;
		if (objSearch.test(strText)) {
			var resArray = strText.match(objSearch);
			for (i=0; resArray.length > i; i++) {
				newindex = strText.indexOf(resArray[i], index);
				var string = resArray[i];
				var file = string.match(objSearch);
				GenFiles[i] = RegExp.$1;
				// If a filename starts by './', change the path to be absolute
				if (objSearchDir.test(GenFiles[i])) { 
					GenFiles[i] = app.ExtractFilePath(mySRDialog.FileDoc) + 
						GenFiles[i].slice(2);
				}
				index = newindex + resArray[i].length;
			}
			return GenFiles;
		} else { 
			return false;
		}
	}	   
}


function Main() {
// Set Current View to Edit.
app.CurrentView = 1;

// Everything will work only if the active file has extensions 'htp' or 'def'.
var objSearch = /\.htp$|\.def$/i;	
fname = app.ExtractFileName(active.Filename);
if (! objSearch.test(fname)) {
	app.MessageBox("Active file must have extensions '.htp' or '.def'", "Wrong Htmlpp Extension", hsOKAlert);	
	return;
}

// Create Dialog Control and Define Default Values for All the Options.
var objScript = new ActiveXObject("ScriptX.Factory");
objScript.script = this;

mySRDialog.OptDebug = true;	// default to Debug Mode
mySRDialog.OptGuru = false;	// default to Not Guru Mode
mySRDialog.OptEnv = true;	// default to Load Environment Symbols
mySRDialog.OptNofunc = false;	// default to No Nofunc
mySRDialog.OptConnect = false;	// default to Process Connected Docs
mySRDialog.OptNoconnect = false;	// default to Store Connected Docs
mySRDialog.OptExpired = false;	// default Not to process Expired Docs
mySRDialog.SetSpanish = true;	// default to Process the Spanish Version
mySRDialog.SetEnglish = false;	// default to Process the English Version
mySRDialog.Charset = "ISO";	// default to ISO-8859-1 Charset
mySRDialog.FileDoc = active.Filename;	// default document is active one
mySRDialog.EditOutput = true;	// default to Edit Runtime Output from Htmlpp after processing
mySRDialog.EditWrk = false;		// default to Edit Working Files after processing
mySRDialog.EditHTML = false;	// default to Edit Generated HTML files after processing
mySRDialog.BrowseHTML = true;	// default to Browse First Generated HTML file after processing

if (objScript.ShowHtmlDialog(app.AppPath + HtmlppScriptsPath + "htmlpp_dialog.html",  mySRDialog) != false) {	// if the user didn't cancel

	// First close all open documents related to Htmlpp so that they are not mixed with the
	// current preprocessing documents.  (note that DocumentCount is 1-based,
    // whereas DocumentCache() is 0-based). Also note that i is not incremented when a file
	// is closed because as there is one file less in the Tab index, i correspond to the next file.
	objSearch = /html000\d\.wrk/;	
	var i = 0;
    while (i < app.DocumentCount) {
		// get document name
        fname = app.ExtractFileName(app.DocumentCache(i).Filename);

		if (fname == "htmlpp.out" || fname == "errors.lst" || objSearch.test(fname)) {
			app.DocumentIndex = i;
			active.Close(false);		
		}
		else {
			i++;
		}
	}

	var args = (mySRDialog.OptDebug ? "-debug " : "") + (mySRDialog.OptGuru ? "-guru " : "") +
	 	(mySRDialog.OptEnv ? "-env " : "") + (mySRDialog.OptNofunc ? "-nofunc " : "") + 
	 	(mySRDialog.OptConnect ? "-connect " : "") + (mySRDialog.OptNoconnect ? "-noconnect " : "") +
		(mySRDialog.OptExpired ? "-expired " : "") + (mySRDialog.Charset == "ISO" ? '-charset "iso-8859-1" ' : "") +
		(mySRDialog.Charset == "DOS" ? '-charset dos ' : "");
		
	if (mySRDialog.Pages != "") {
		args += '-page "' + mySRDialog.Pages + '" ';
	}

	if (mySRDialog.Set != "") {
		var SetValues = new Array();
		SetValues = mySRDialog.Set.split(",");
		for (i = 0; i < SetValues.length; i++) {
			args += '-set "' + SetValues[i] + '" ';
		}
	}
	
	// The first argument to send to htmlpp_hs is the directory where the source 
	// htmlpp document lives. Then all the arguments to htmlpp are passed.		
	if (mySRDialog.SetSpanish && mySRDialog.SetEnglish) { // Process both languages
		var command = "perl " + HtmlppPath + "htmlpp_hs.pl " + app.ExtractFilePath(mySRDialog.FileDoc) + 
		" " + args + ' -set "LANG=es" ' + app.ExtractFileName(mySRDialog.FileDoc) +
		'  -set "LANG=en" ' + app.ExtractFileName(mySRDialog.FileDoc);
	}
	else { // Process only one language
		args += (mySRDialog.SetSpanish ? '-set "LANG=es" ' : "") + 
		(mySRDialog.SetEnglish ? '-set "LANG=en" ' : "");
		var command = "perl " + HtmlppPath + "htmlpp_hs.pl " + app.ExtractFilePath(mySRDialog.FileDoc) + 
		" " + args + " " + app.ExtractFileName(mySRDialog.FileDoc);	
	}

	app.ShellToAppAndWait(command); 

	// Define all files related to Htmlpp output
	var OutputFile = app.ExtractFilePath(mySRDialog.FileDoc) + "htmlpp.out";
	var ErrorFile = app.ExtractFilePath(mySRDialog.FileDoc) + "errors.lst";
	var WrkFile = app.ExtractFilePath(mySRDialog.FileDoc) + "html000";
	var WrkFileExt = ".wrk";
	var LastProcessFile = app.AppPath + HtmlppScriptsPath +  "last_proc.txt";
	
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var LastProcessFileObj = fso.CreateTextFile(LastProcessFile, true);
	LastProcessFileObj.WriteLine("SourceFile = " + mySRDialog.FileDoc);
	
	// Now check for the existence of all those files and 
	// store all the info in 'last_proc.txt'
	if (fso.FileExists(OutputFile)) { // Run-time Output from Htmlpp
		var GenOutputFile = true;
		LastProcessFileObj.WriteLine("OutputFile = " + OutputFile);		
		// Let's parse the Output file first without opening it, and obtain all
		// generated HTML files
		var OutputFileTxt = fso.OpenTextFile(OutputFile, ForReading, false);
		var GenHTMLFiles = ReturnHTMLFiles(OutputFileTxt.ReadAll());
		OutputFileTxt.Close();
		for (i=0 ; i < GenHTMLFiles.length; i++) {
			LastProcessFileObj.WriteLine("HTMLFile = " + GenHTMLFiles[i]);
		}
	} else {
		var GenOutputFile = false;
		LastProcessFileObj.WriteLine("OutputFile = NONE");		
	}
	
	if (fso.FileExists(WrkFile + "1" + WrkFileExt)) { // Working Files
		var GenWrkFiles = new Array();	
		i = 1;		
		while (fso.FileExists(WrkFile + i + WrkFileExt)) {
			GenWrkFiles[i-1] = WrkFile + i + WrkFileExt;
			LastProcessFileObj.WriteLine("WrkFile = " + GenWrkFiles[i-1]);						
			i++;
		}
	} else {
		var GenWrkFiles = false;
		LastProcessFileObj.WriteLine("WrkFile = NONE");		
	}

	if (fso.FileExists(ErrorFile)) { // Errors file
		var GenErrorFile  = true;
		LastProcessFileObj.WriteLine("ErrorsFile = " + ErrorFile);		
	} else {
		LastProcessFileObj.WriteLine("ErrorsFile = NONE");			
	}
	
	LastProcessFileObj.Close();
	
	// Open working files if it was selected and the preprocessing was done in Debug mode.			
	if (mySRDialog.EditWrk && mySRDialog.OptDebug && GenWrkFiles) {
		for (i = 0; i < GenWrkFiles.length; i++) {
			app.OpenFile(GenWrkFiles[i]);
		}
	}

	// Open the output file if it exists.	
	if (mySRDialog.EditOutput && GenOutputFile) {
		app.OpenFile(OutputFile);
	} else {
		app.MessageBox("Run-time Output File 'htmlpp.out' not found", "No Output", hsOKAlert);						
	}

	// Prompt to open the error file if it exists	
	if (GenErrorFile) {
		answer = app.MessageBox("There were errors. Do you want to open the 'errors.lst' file?",
			"Htmlpp Error",hsYesNoQuestion);
		if (answer == 6 ) {
			app.OpenFile(ErrorFile);
		}
	}

	// Open/Browse the generated HTML files	if they exist
  	if (mySRDialog.EditHTML || mySRDialog.BrowseHTML) {
		if (GenOutputFile) {
			if (GenHTMLFiles) {
				if (mySRDialog.EditHTML) {
					for (i=0; i < GenHTMLFiles.length;	i++) {
						if (app.IsFileOpen(GenHTMLFiles[i])) { // If it's open just make it active
							app.DocumentIndex = app.GetTabIndexForFile(GenHTMLFiles[i]);
						} else { // Or else open it
							app.OpenFile(GenHTMLFiles[i]);
						}
					}
					if (mySRDialog.BrowseHTML) {
						app.DocumentIndex = app.GetTabIndexForFile(GenHTMLFiles[0]);
						app.CurrentView = 2;					
					}
				} else {
					if (app.IsFileOpen(GenHTMLFiles[0])) { // If it's open just make it active
						app.DocumentIndex = app.GetTabIndexForFile(GenHTMLFiles[0]);
					} else { // Or else open it
						app.OpenFile(GenHTMLFiles[0]);
					}
					app.CurrentView = 2;					
				}
			} else {
				app.MessageBox("No Generated HTML Files Found", "No HTML Output", hsOKAlert);
			}
		}
	}

}	// end if not cancelled (dialog return value = false)

}	// end Main
