#! /opt/perl/perl
############################################################################
# htmlpp_hs.pl   Run Htmlpp from htmlpp.js HomeSite 4.0 Active Script.
#
#   First argument is the directory where the document(s) to be processed is.
#   All other arguments are passed to Htmlpp.
#   A ".bat" file is not used because it can only pass up to 9 arguments,
#   which is too little very often.
#
#   Written by Enrique Bengoechea.
#   Use with version 0.1 of htmlpp.js
############################################################################

# We have to set the directory or Htmlpp will not find auxiliary files like
# expires.def, connect.def, etc.
Win32::SetCwd("$ARGV[0]");

# Erase htmlpp.out if it exists, so that if some error occurrs and htmlpp.out
# is not generated, htmlpp.js will not edit the old htmlpp.out
unlink("htmlpp.out") if (-e "htmlpp.out");
shift @ARGV;
$args = join (" ",@ARGV);
print "htmlpp $args\n\nPlease wait...";

# Invoke Htmlpp
$try = `perl C:\\htmlpp\\htmlpp.pl $args >htmlpp.out`;
